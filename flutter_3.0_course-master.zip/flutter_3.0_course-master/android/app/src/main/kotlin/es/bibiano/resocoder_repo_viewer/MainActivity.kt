package es.bibiano.resocoder_repo_viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
