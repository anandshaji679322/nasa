import 'dart:convert';

final stringToBase64 = utf8.fuse(base64);
