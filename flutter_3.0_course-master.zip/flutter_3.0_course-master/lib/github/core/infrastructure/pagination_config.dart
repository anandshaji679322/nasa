class PaginationConfig {
  static const int itemsPerPage = 15;
}
